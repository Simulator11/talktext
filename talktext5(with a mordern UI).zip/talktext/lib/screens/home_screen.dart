import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../screens/welcome_screen.dart';
import '../screens/edit_profile_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/new_chat_screen.dart';

class HomeScreen extends StatefulWidget {
  final String username;
  final String phone;

  const HomeScreen({Key? key, required this.username, required this.phone})
      : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  late final List<Widget> _pages;
  late FlutterTts flutterTts;
  final stt.SpeechToText _speech = stt.SpeechToText();
  DateTime? _lastTap;
  bool _isMagnified = false;

  // Light blue color scheme
  final Color _primaryColor = Colors.lightBlue.shade400;
  final Color _secondaryColor = Colors.lightBlue.shade200;
  final Color _accentColor = Colors.blueAccent;
  final Color _textColor = Colors.blueGrey.shade800;

  @override
  void initState() {
    super.initState();
    flutterTts = FlutterTts();
    _initializeTts();
    _initializeSpeech();

    _pages = [
      _buildHomeContent(),
      _buildChatsPlaceholder(),
      NewChatScreen(currentUserPhone: widget.phone),
      ProfileScreen(
        username: widget.username,
        phone: widget.phone,
        userId: '',
      ),
    ];

    _speakWelcomeMessage();
  }

  Future<void> _initializeTts() async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.setSpeechRate(0.5);
  }

  Future<void> _initializeSpeech() async {
    await _speech.initialize();
  }

  Future<void> _speakWelcomeMessage() async {
    await flutterTts.speak(
        "Welcome to TalkText, ${widget.username}. "
            "Double tap any item to select it. "
            "Swipe right for menu or use bottom navigation."
    );
  }

  Future<void> _speak(String text) async {
    await flutterTts.stop();
    await flutterTts.speak(text);
  }

  void _handleDoubleTap(BuildContext context, String description, [GestureTapCallback? action]) {
    final now = DateTime.now();
    if (_lastTap != null && now.difference(_lastTap!) < Duration(milliseconds: 300)) {
      _lastTap = null;
      if (action != null) action();
    } else {
      _lastTap = now;
      _speak(description);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TalkText',
          style: GoogleFonts.poppins(
            fontSize: _isMagnified ? 24 : 20,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: _primaryColor,
        actions: [_buildMagnifierButton()],
      ),
      drawer: _buildAccessibleDrawer(context),
      body: GestureDetector(
        onTap: () => _speak("Home screen content"),
        child: _pages[_currentIndex],
      ),
      bottomNavigationBar: _buildModernBottomNavBar(),
    );
  }

  Widget _buildMagnifierButton() {
    return IconButton(
      icon: Icon(
        _isMagnified ? Icons.zoom_out_map : Icons.zoom_in,
        color: Colors.white,
        size: _isMagnified ? 28 : 24,
      ),
      onPressed: () {
        setState(() => _isMagnified = !_isMagnified);
        _speak(_isMagnified ? "Magnified view" : "Normal view");
      },
      tooltip: 'Toggle text size',
    );
  }

  Widget _buildAccessibleDrawer(BuildContext context) {
    return Drawer(
      child: Container(
        color: _primaryColor,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: _accentColor),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () => _handleDoubleTap(context, "User profile"),
                    child: CircleAvatar(
                      radius: _isMagnified ? 40 : 30,
                      backgroundColor: Colors.white,
                      child: Icon(
                        Icons.account_circle_rounded,
                        size: _isMagnified ? 50 : 40,
                        color: _primaryColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  GestureDetector(
                    onTap: () => _handleDoubleTap(context, "Welcome message"),
                    child: Text(
                      'Welcome!',
                      style: GoogleFonts.poppins(
                        fontSize: _isMagnified ? 24 : 20,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              color: _secondaryColor,
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () => _handleDoubleTap(context, "Username ${widget.username}"),
                    child: Text(
                      widget.username,
                      style: GoogleFonts.poppins(
                        fontSize: _isMagnified ? 20 : 16,
                        fontWeight: FontWeight.w500,
                        color: _textColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  GestureDetector(
                    onTap: () => _handleDoubleTap(context, "Phone number ${widget.phone}"),
                    child: Text(
                      widget.phone,
                      style: GoogleFonts.poppins(
                        fontSize: _isMagnified ? 18 : 14,
                        color: _textColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            _buildDrawerItem(
              context,
              icon: Icons.home_rounded,
              text: "Home",
              onTap: () {
                setState(() => _currentIndex = 0);
                Navigator.pop(context);
              },
            ),
            _buildDrawerItem(
              context,
              icon: Icons.forum_rounded,
              text: "Chats",
              onTap: () {
                setState(() => _currentIndex = 1);
                Navigator.pop(context);
              },
            ),
            _buildDrawerItem(
              context,
              icon: Icons.add_comment_rounded,
              text: "New Chat",
              onTap: () {
                setState(() => _currentIndex = 2);
                Navigator.pop(context);
              },
            ),
            _buildDrawerItem(
              context,
              icon: Icons.edit_rounded,
              text: "Edit Profile",
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EditProfileScreen()),
                );
              },
            ),
            _buildDrawerItem(
              context,
              icon: Icons.logout_rounded,
              text: "Logout",
              onTap: () => logout(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(BuildContext context, {
    required IconData icon,
    required String text,
    required GestureTapCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: _textColor),
      title: Text(text,
        style: GoogleFonts.poppins(
          fontSize: _isMagnified ? 18 : 14,
          color: _textColor,
        ),
      ),
      onTap: () {
        _speak("Opening $text");
        onTap();
      },
      tileColor: Colors.white.withOpacity(0.8),
    );
  }

  Widget _buildModernBottomNavBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      onTap: (index) {
        setState(() => _currentIndex = index);
        _speak(_getNavItemName(index));
      },
      backgroundColor: _primaryColor,
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.white.withOpacity(0.7),
      selectedFontSize: _isMagnified ? 14 : 12,
      unselectedFontSize: _isMagnified ? 12 : 10,
      type: BottomNavigationBarType.fixed,
      selectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w500),
      unselectedLabelStyle: GoogleFonts.poppins(),
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_rounded),
          activeIcon: Icon(Icons.home_filled),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.forum_rounded),
          activeIcon: Icon(Icons.forum),
          label: 'Chats',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.add_comment_rounded),
          activeIcon: Icon(Icons.add_comment),
          label: 'New Chat',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_rounded),
          activeIcon: Icon(Icons.person),
          label: 'Profile',
        ),
      ],
    );
  }

  Widget _buildHomeContent() {
    return RefreshIndicator(
      onRefresh: _speakWelcomeMessage,
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Padding(
          padding: EdgeInsets.all(_isMagnified ? 20 : 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => _handleDoubleTap(
                    context,
                    "Welcome card for ${widget.username}"
                ),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  color: Colors.white,
                  child: Padding(
                    padding: EdgeInsets.all(_isMagnified ? 20 : 16),
                    child: Row(
                      children: [
                        Icon(
                          Icons.account_circle_rounded,
                          size: _isMagnified ? 60 : 50,
                          color: _primaryColor,
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Welcome, ${widget.username}!',
                                style: GoogleFonts.poppins(
                                  fontSize: _isMagnified ? 20 : 16,
                                  fontWeight: FontWeight.w600,
                                  color: _textColor,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Phone: ${widget.phone}',
                                style: GoogleFonts.poppins(
                                  fontSize: _isMagnified ? 16 : 14,
                                  color: _textColor.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(height: _isMagnified ? 30 : 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  "Recent Chats",
                  style: GoogleFonts.poppins(
                    fontSize: _isMagnified ? 20 : 16,
                    fontWeight: FontWeight.w600,
                    color: _textColor,
                  ),
                ),
              ),
              SizedBox(height: _isMagnified ? 20 : 12),
              _buildRecentChatsPlaceholder(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChatsPlaceholder() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.forum_rounded,
            size: _isMagnified ? 80 : 60,
            color: _primaryColor.withOpacity(0.3),
          ),
          SizedBox(height: 16),
          Text(
            "Your chats will appear here",
            style: GoogleFonts.poppins(
              fontSize: _isMagnified ? 18 : 14,
              color: _textColor.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentChatsPlaceholder() {
    return Center(
      child: Column(
        children: [
          Icon(
            Icons.chat_bubble_outline_rounded,
            size: _isMagnified ? 80 : 60,
            color: _primaryColor.withOpacity(0.3),
          ),
          SizedBox(height: 16),
          Text(
            "No recent chats",
            style: GoogleFonts.poppins(
              fontSize: _isMagnified ? 18 : 14,
              color: _textColor.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  String _getNavItemName(int index) {
    switch (index) {
      case 0: return "Home";
      case 1: return "Chats";
      case 2: return "New Chat";
      case 3: return "Profile";
      default: return "";
    }
  }

  Future<void> logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => WelcomeScreen()),
    );
  }

  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }
}