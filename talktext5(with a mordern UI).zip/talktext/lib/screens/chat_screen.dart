import 'package:flutter/material.dart';
import '../models/message.dart';
import '../models/user_model.dart';
import '../services/chat_service.dart';
import '../services/tts_service.dart';

class ChatScreen extends StatefulWidget {
  final String currentUserPhone;
  final User otherUser;

  const ChatScreen({Key? key, required this.currentUserPhone, required this.otherUser}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ChatService _chatService = ChatService(baseUrl: 'http://192.168.1.188/TALKTEXT');
  final TtsService _tts = TtsService();
  late Future<List<Message>> _messagesFuture;
  final TextEditingController _messageController = TextEditingController();
  late List<Message> _messages;

  @override
  void initState() {
    super.initState();
    _messages = [];
    _loadMessages();
  }

  Future<void> _loadMessages() async {
    List<Message> messages = await _chatService.getMessages(
      senderPhone: widget.currentUserPhone,
      receiverPhone: widget.otherUser.phone,
    );
    setState(() {
      _messages = messages;
    });
  }

  void _sendMessage() async {
    String messageText = _messageController.text;
    if (messageText.isNotEmpty) {
      await _chatService.sendMessage(
        senderPhone: widget.currentUserPhone,
        receiverPhone: widget.otherUser.phone,
        message: messageText,
      );
      _messageController.clear();
      _loadMessages(); // Fetch new messages after sending
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat with ${widget.otherUser.username}"),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true, // Ensure newer messages appear at the bottom
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                bool isSender = message.senderPhone == widget.currentUserPhone;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                  child: Align(
                    alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
                      decoration: BoxDecoration(
                        color: isSender ? Colors.blueAccent : Colors.grey[300],
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: Text(
                        message.message, // Access message property
                        style: TextStyle(
                          color: isSender ? Colors.white : Colors.black,
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: "Type a message",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
