package com.example.talktext

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
