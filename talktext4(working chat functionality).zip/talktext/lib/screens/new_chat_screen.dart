import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/chat_service.dart';
import '../screens/chat_screen.dart';
import '../services/tts_service.dart';

class NewChatScreen extends StatefulWidget {
  final String currentUserPhone;

  const NewChatScreen({Key? key, required this.currentUserPhone})
      : super(key: key);

  @override
  _NewChatScreenState createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final ChatService _chatService = ChatService(
      baseUrl: 'http://192.168.1.188/TALKTEXT');
  final TtsService _tts = TtsService();
  late Future<List<User>> _userFuture;


  @override
  void initState() {
    super.initState();
    _userFuture = _loadAndAnnounceUsers();
  }

  Future<List<User>> _loadAndAnnounceUsers() async {
    List<User> users = await _chatService.fetchUsers(widget.currentUserPhone);

    if (users.isNotEmpty) {
      String names = users.map((u) => u.username).join(', ');
      await _tts.speak("Users available to chat are: $names");
    } else {
      await _tts.speak("No users available to chat at the moment.");
    }

    return users;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Start New Chat"),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: FutureBuilder<List<User>>(
        future: _userFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return Center(child: CircularProgressIndicator());

          if (snapshot.hasError)
            return Center(child: Text("Error: ${snapshot.error}"));

          final users = snapshot.data!;
          return ListView.builder(
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index];
              return ListTile(
                leading: CircleAvatar(child: Text(user.username[0])),
                title: Text(user.username),
                subtitle: Text(user.phone),
                onTap: () async {
                  await _tts.speak("Starting chat with ${user.username}");
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          ChatScreen(
                            currentUserPhone: widget.currentUserPhone,
                            otherUser: user,
                          ),
                    ),
                  );
                },
                onLongPress: () async {
                  await _tts.speak(user.username);
                },
              );
            },
          );
        },
      ),
    );
  }
}