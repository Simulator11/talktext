import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../screens/welcome_screen.dart';
import '../screens/edit_profile_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/new_chat_screen.dart';

class HomeScreen extends StatefulWidget {
  final String username;
  final String phone;

  const HomeScreen({Key? key, required this.username, required this.phone})
      : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  late final List<Widget> _pages;
  late FlutterTts flutterTts;

  @override
  void initState() {
    super.initState();

    _pages = [
      _buildHomeContent(),
      NewChatScreen(currentUserPhone: widget.phone),
      ProfileScreen(
        username: widget.username,
        phone: widget.phone,
        userId: '',
      ),
    ];

    flutterTts = FlutterTts();
    _speakWelcomeMessage();
  }

  Future<void> _speakWelcomeMessage() async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.setSpeechRate(0.5);

    String welcomeText =
        "Welcome to TalkText, ${widget.username}. "
        "Your phone number is ${widget.phone}. "
        "On your top left there is a menu icon. "
        "Click it to see the details of your profile, "
        "edit your profile or to log out of the app. "
        "Use the bottom navigation to go to Home, New Chat, or Profile. "
        "Or scroll top down to refresh and listen again.";

    await flutterTts.speak(welcomeText);
  }

  Future<void> _speakBottomNavLabel(int index) async {
    switch (index) {
      case 0:
        await flutterTts.speak("Home");
        break;
      case 1:
        await flutterTts.speak("New Chat");
        break;
      case 2:
        await flutterTts.speak("Profile");
        break;
    }
  }

  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }

  Future<void> logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => WelcomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TalkText Home'),
        backgroundColor: Colors.lightBlueAccent,
      ),
      drawer: Drawer(
        child: SingleChildScrollView(
          child: Container(
            color: Colors.lightBlueAccent,
            child: Column(
              children: [
                DrawerHeader(
                  decoration: BoxDecoration(color: Colors.blueAccent),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: double.infinity,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 50,
                              backgroundColor: Colors.white,
                              child: Icon(
                                Icons.account_circle,
                                size: 60,
                                color: Colors.blueAccent,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Welcome!',
                              style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  color: Colors.blueGrey[800],
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 16.0),
                  child: Column(
                    children: [
                      Text(
                        widget.username,
                        style: TextStyle(fontSize: 22, color: Colors.white),
                      ),
                      SizedBox(height: 5),
                      Text(
                        widget.phone,
                        style: TextStyle(fontSize: 18, color: Colors.white70),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  leading: Icon(Icons.home, color: Colors.white),
                  title: Text('Home',
                      style: TextStyle(fontSize: 18, color: Colors.white)),
                  onTap: () {
                    setState(() {
                      _currentIndex = 0;
                    });
                    Navigator.pop(context);
                  },
                ),
                ListTile(
                  leading: Icon(Icons.edit, color: Colors.white),
                  title: Text('Edit Profile',
                      style: TextStyle(fontSize: 18, color: Colors.white)),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EditProfileScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.logout, color: Colors.white),
                  title: Text('Logout',
                      style: TextStyle(fontSize: 18, color: Colors.white)),
                  onTap: () => logout(context),
                ),
              ],
            ),
          ),
        ),
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
          _speakBottomNavLabel(index);
        },
        backgroundColor: Colors.lightBlueAccent,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black54,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'New Chat'),
          BottomNavigationBarItem(
              icon: Icon(Icons.account_circle), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    return RefreshIndicator(
      onRefresh: _speakWelcomeMessage,
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                color: Colors.lightBlue.shade100,
                child: ListTile(
                  leading: Icon(Icons.account_circle,
                      size: 50, color: Colors.blueAccent),
                  title: Text(
                    'Welcome, ${widget.username}!',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    'Phone: ${widget.phone}',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Recent Chats",
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent),
              ),
              SizedBox(height: 10),
              _buildRecentChatsPlaceholder(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentChatsPlaceholder() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(top: 100),
        child: Text(
          "No recent chats",
          style: TextStyle(fontSize: 18, color: Colors.black54),
        ),
      ),
    );
  }
}
