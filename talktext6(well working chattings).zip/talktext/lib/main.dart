import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../screens/home_screen.dart';
import '../screens/welcome_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Ensure Flutter is initialized before using async

  // Load user data from shared preferences
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? username = prefs.getString("username");
  String? phone = prefs.getString("phone");

  runApp(MyApp(username: username, phone: phone));
}

class MyApp extends StatelessWidget {
  final String? username;
  final String? phone;

  const MyApp({Key? key, this.username, this.phone}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "TalkText",
      theme: ThemeData(primarySwatch: Colors.blue),
      home: (username != null && phone != null)
          ? HomeScreen(username: username!, phone: phone!)
          : WelcomeScreen(),
    );
  }
}
