import 'package:speech_to_text/speech_to_text.dart' as stt;

class SttService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isInitialized = false;

  Future<bool> initialize() async {
    if (!_isInitialized) {
      _isInitialized = await _speech.initialize(
        onError: (error) => print("Speech init error: $error"),
        onStatus: (status) => print("Speech status: $status"),
      );
    }
    return _isInitialized;
  }

  Future<String?> listen() async {
    bool available = await initialize();
    if (!available) {
      print("Speech recognition not available.");
      return null;
    }

    String? recognizedText;

    try {
      await _speech.listen(
        onResult: (result) {
          if (result.finalResult) {
            recognizedText = result.recognizedWords;
          }
        },
        listenFor: const Duration(seconds: 10),
        pauseFor: const Duration(seconds: 3),
        localeId: "en_US", // Adjust locale as needed
        cancelOnError: true,
        partialResults: false,
      );

      // Wait for the result or timeout
      await Future.delayed(Duration(seconds: 12));
      await _speech.stop();
    } catch (e) {
      print("Speech-to-Text error: $e");
    }

    return recognizedText;
  }

  void stop() {
    _speech.stop();
  }

  void cancel() {
    _speech.cancel();
  }
}
