import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';

class SettingsScreen extends StatefulWidget {
  final Function() onSettingsChanged;
  final bool isMagnified;

  const SettingsScreen({
    Key? key,
    required this.onSettingsChanged,
    required this.isMagnified,
  }) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late String _selectedLanguage;
  late bool _darkMode;
  late bool _soundEffects;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _selectedLanguage = prefs.getString('language') ?? 'en';
      _darkMode = prefs.getBool('darkMode') ?? false;
      _soundEffects = prefs.getBool('soundEffects') ?? true;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', _selectedLanguage);
    await prefs.setBool('darkMode', _darkMode);
    await prefs.setBool('soundEffects', _soundEffects);
    widget.onSettingsChanged();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Settings',
          style: GoogleFonts.poppins(
            fontSize: widget.isMagnified ? 24 : 20,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildSectionHeader('Language Settings'),
            _buildLanguageSetting(),
            _buildSectionHeader('Appearance'),
            _buildDarkModeSetting(),
            _buildSectionHeader('Sound'),
            _buildSoundEffectsSetting(),
            _buildSaveButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: GoogleFonts.poppins(
          fontSize: widget.isMagnified ? 20 : 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildLanguageSetting() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'App Language',
              style: GoogleFonts.poppins(
                fontSize: widget.isMagnified ? 18 : 14,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: RadioListTile<String>(
                    title: Text(
                      'English',
                      style: GoogleFonts.poppins(
                        fontSize: widget.isMagnified ? 16 : 12,
                      ),
                    ),
                    value: 'en',
                    groupValue: _selectedLanguage,
                    onChanged: (value) {
                      setState(() {
                        _selectedLanguage = value!;
                      });
                    },
                  ),
                ),
                Expanded(
                  child: RadioListTile<String>(
                    title: Text(
                      'Swahili',
                      style: GoogleFonts.poppins(
                        fontSize: widget.isMagnified ? 16 : 12,
                      ),
                    ),
                    value: 'sw',
                    groupValue: _selectedLanguage,
                    onChanged: (value) {
                      setState(() {
                        _selectedLanguage = value!;
                      });
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDarkModeSetting() {
    return Card(
      child: SwitchListTile(
        title: Text(
          'Dark Mode',
          style: GoogleFonts.poppins(
            fontSize: widget.isMagnified ? 18 : 14,
          ),
        ),
        value: _darkMode,
        onChanged: (value) {
          setState(() {
            _darkMode = value;
          });
        },
      ),
    );
  }

  Widget _buildSoundEffectsSetting() {
    return Card(
      child: SwitchListTile(
        title: Text(
          'Sound Effects',
          style: GoogleFonts.poppins(
            fontSize: widget.isMagnified ? 18 : 14,
          ),
        ),
        value: _soundEffects,
        onChanged: (value) {
          setState(() {
            _soundEffects = value;
          });
        },
      ),
    );
  }

  Widget _buildSaveButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: ElevatedButton(
        onPressed: () async {
          await _saveSettings();
          Navigator.pop(context);
        },
        child: Text(
          'Save Settings',
          style: GoogleFonts.poppins(
            fontSize: widget.isMagnified ? 18 : 14,
          ),
        ),
      ),
    );
  }
}