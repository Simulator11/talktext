import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'login_screen.dart';

class WelcomeScreen extends StatefulWidget {
  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final FlutterTts flutterTts = FlutterTts();
  bool _isMagnified = false;

  @override
  void initState() {
    super.initState();
    _speakWelcomeMessage();
  }

  Future<void> _speakWelcomeMessage() async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.setSpeechRate(0.45);
    await flutterTts.speak(
      "Welcome to TalkText, a final year project for Japhet Onesmo Samwel, under the supervision of Mr. Jovine Camara, class of 2025.",
    );
  }

  Widget _buildMagnifierButton() {
    return IconButton(
      icon: Icon(
        Icons.zoom_in,
        color: Colors.white,
        size: _isMagnified ? 30 : 24,
      ),
      onPressed: () {
        setState(() => _isMagnified = !_isMagnified);
        flutterTts.speak(_isMagnified ? "Magnified view" : "Normal view");
      },
      tooltip: 'Toggle text size',
    );
  }

  TextStyle _getTextStyle(bool isTitle) {
    return TextStyle(
      fontSize: _isMagnified
          ? (isTitle ? 40 : 24)
          : (isTitle ? 32 : 18),
      fontWeight: _isMagnified ? FontWeight.bold : FontWeight.normal,
      color: Colors.white,
    );
  }

  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Modern gradient background (replacing image)
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.blue.shade800,
                  Colors.lightBlue.shade400,
                ],
              ),
            ),
          ),

          // App bar with magnifier button
          Positioned(
            top: MediaQuery.of(context).padding.top + 10,
            right: 20,
            child: _buildMagnifierButton(),
          ),

          // Main Content
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // App logo/icon
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.chat_bubble_outline,
                      size: _isMagnified ? 80 : 60,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: _isMagnified ? 40 : 30),

                  // App title
                  Text(
                    "Welcome to TalkText",
                    textAlign: TextAlign.center,
                    style: _getTextStyle(true).copyWith(
                      shadows: [
                        Shadow(
                          blurRadius: 8,
                          color: Colors.black.withOpacity(0.3),
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: _isMagnified ? 30 : 20),

                  // Project description
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 16,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      "A final year project by Japhet Onesmo Samwel,\n"
                          "under the supervision of Mr. Jovine Camara\n"
                          "Class of 2025.",
                      textAlign: TextAlign.center,
                      style: _getTextStyle(false).copyWith(
                        height: 1.5,
                      ),
                    ),
                  ),
                  SizedBox(height: _isMagnified ? 50 : 40),

                  // Get started button
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.blue.shade800,
                      padding: EdgeInsets.symmetric(
                        horizontal: _isMagnified ? 60 : 40,
                        vertical: _isMagnified ? 20 : 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      elevation: 8,
                      shadowColor: Colors.black.withOpacity(0.3),
                    ),
                    onPressed: () {
                      flutterTts.stop();
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    child: Text(
                      "Get Started",
                      style: _getTextStyle(false).copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}