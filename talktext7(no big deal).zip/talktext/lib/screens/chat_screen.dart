import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:google_fonts/google_fonts.dart';
import '../models/message.dart';
import '../models/user_model.dart';
import '../services/chat_service.dart';
import '../services/tts_service.dart';
import 'dart:async';

class ChatScreen extends StatefulWidget {
  final String currentUserPhone;
  final User otherUser;

  const ChatScreen({Key? key, required this.currentUserPhone, required this.otherUser}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ChatService _chatService = ChatService(baseUrl: 'http://192.168.1.188/TALKTEXT');
  final TtsService _tts = TtsService();
  final TextEditingController _messageController = TextEditingController();
  late List<Message> _messages;
  late ScrollController _scrollController;

  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _recognizedText = '';
  String _speechLocale = 'sw_KE'; // Default to Swahili

  @override
  void initState() {
    super.initState();
    _messages = [];
    _scrollController = ScrollController();
    _speech = stt.SpeechToText();
    _loadMessages();
    _initializeSpeech();
    _tts.setLanguage('sw'); // Set Swahili for TTS

    Timer.periodic(Duration(seconds: 5), (timer) {
      if (mounted) _loadMessages();
    });
  }

  Future<void> _initializeSpeech() async {
    bool available = await _speech.initialize(
      onStatus: (status) => print('Speech status: $status'),
      onError: (error) => print('Speech error: $error'),
    );

    if (!available) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Speech recognition not available')),
      );
    }
  }

  Future<void> _loadMessages() async {
    List<Message> messages = await _chatService.getMessages(
      senderPhone: widget.currentUserPhone,
      receiverPhone: widget.otherUser.phone,
    );
    setState(() => _messages = messages);
    _scrollToBottom();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    }
  }

  void _startListening() async {
    if (!_isListening) {
      bool available = await _speech.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (result) {
            setState(() {
              _recognizedText = result.recognizedWords;
              _messageController.text = _recognizedText;
              _speechLocale = _detectSwahili(_recognizedText) ? 'sw_KE' : 'en_US';
            });
          },
          listenFor: Duration(minutes: 1),
          pauseFor: Duration(seconds: 3),
          localeId: _speechLocale,
        );
      }
    }
  }

  void _stopListening() async {
    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
    }
  }

  void _sendMessage() async {
    String messageText = _messageController.text;
    if (messageText.isNotEmpty) {
      await _chatService.sendMessage(
        senderPhone: widget.currentUserPhone,
        receiverPhone: widget.otherUser.phone,
        message: messageText,
      );
      _messageController.clear();
      _loadMessages();
      _tts.setLanguage(_detectSwahili(messageText) ? 'sw' : 'en');
      _tts.speak("Ujumbe umetumwa"); // "Message sent" in Swahili
    }
  }

  void _playMessage() async {
    String text = _messageController.text;
    if (text.isNotEmpty) {
      _tts.setLanguage(_detectSwahili(text) ? 'sw' : 'en');
      await _tts.speak(text);
    }
  }

  bool _detectSwahili(String text) {
    final swahiliKeywords = ['habari', 'karibu', 'asante', 'mimi', 'wewe', 'shule', 'ndiyo', 'hapana', 'rafiki'];
    final lowerText = text.toLowerCase();
    return swahiliKeywords.any((word) => lowerText.contains(word));
  }

  String _formatTimestamp(String timestamp) {
    final dt = DateTime.parse(timestamp);
    return "${dt.hour}:${dt.minute.toString().padLeft(2, '0')} ${dt.day}/${dt.month}/${dt.year}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat with ${widget.otherUser.username}"),
        backgroundColor: Colors.lightBlueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.volume_up),
            onPressed: () {
              _tts.setLanguage(_detectSwahili(widget.otherUser.username) ? 'sw' : 'en');
              _tts.speak("Unazungumza na ${widget.otherUser.username}");
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                bool isSender = message.senderPhone == widget.currentUserPhone;
                return GestureDetector(
                  onTap: () {
                    _tts.setLanguage(_detectSwahili(message.message) ? 'sw' : 'en');
                    _tts.speak(
                        "${isSender ? 'Ulisema' : '${widget.otherUser.username} alisema'}: ${message.message}");
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    child: Align(
                      alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
                        decoration: BoxDecoration(
                          color: isSender ? Colors.lightBlueAccent : Colors.blue,
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              message.message,
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 16.0,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _formatTimestamp(message.timestamp),
                              style: GoogleFonts.poppins(
                                color: Colors.grey[200],
                                fontSize: 12.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(
                    _isListening ? Icons.mic_off : Icons.mic,
                    color: _isListening ? Colors.red : Colors.lightBlueAccent,
                  ),
                  onPressed: () {
                    if (_isListening) {
                      _stopListening();
                    } else {
                      _startListening();
                    }
                  },
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    maxLines: null,
                    minLines: 1,
                    keyboardType: TextInputType.multiline,
                    decoration: InputDecoration(
                      hintText: "Andika au sema ujumbe",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
                    ),
                    style: GoogleFonts.poppins(),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.play_arrow),
                  color: Colors.blue,
                  onPressed: _playMessage,
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  color: Colors.green,
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _speech.stop();
    super.dispose();
  }
}
