import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/user_model.dart';
import '../services/chat_service.dart';
import '../screens/chat_screen.dart';
import '../services/tts_service.dart';

class NewChatScreen extends StatefulWidget {
  final String currentUserPhone;

  const NewChatScreen({Key? key, required this.currentUserPhone})
      : super(key: key);

  @override
  _NewChatScreenState createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final ChatService _chatService = ChatService(
      baseUrl: 'http://192.168.1.188/TALKTEXT');
  final TtsService _tts = TtsService();
  late Future<List<User>> _userFuture;
  bool _isMagnified = false;
  DateTime? _lastTap;

  // Consistent color scheme with HomeScreen
  final Color _primaryColor = Colors.lightBlue.shade400;
  final Color _secondaryColor = Colors.lightBlue.shade200;
  final Color _accentColor = Colors.blueAccent;
  final Color _textColor = Colors.blueGrey.shade800;

  @override
  void initState() {
    super.initState();
    _userFuture = _loadAndAnnounceUsers();
  }

  Future<List<User>> _loadAndAnnounceUsers() async {
    List<User> users = await _chatService.fetchUsers(widget.currentUserPhone);
    if (users.isNotEmpty) {
      String names = users.map((u) => u.username).join(', ');
      await _tts.speak("Users available to chat are: $names");
    } else {
      await _tts.speak("No users available to chat at the moment.");
    }
    return users;
  }

  Widget _buildMagnifierButton() {
    return IconButton(
      icon: Icon(
        _isMagnified ? Icons.zoom_out_map : Icons.zoom_in,
        color: Colors.white,
        size: _isMagnified ? 28 : 24,
      ),
      onPressed: () {
        setState(() => _isMagnified = !_isMagnified);
        _tts.speak(_isMagnified ? "Magnified view" : "Normal view");
      },
      tooltip: 'Toggle text size',
    );
  }

  TextStyle _getTextStyle(bool isTitle) {
    return GoogleFonts.poppins(
      fontSize: _isMagnified
          ? (isTitle ? 22 : 18)
          : (isTitle ? 18 : 14),
      fontWeight: isTitle ? FontWeight.w600 : FontWeight.normal,
      color: _textColor,
    );
  }

  void _handleTap(User user) async {
    final now = DateTime.now();
    final isDoubleTap = _lastTap != null &&
        now.difference(_lastTap!) < Duration(milliseconds: 300);

    if (isDoubleTap) {
      await _tts.speak("Opening chat with ${user.username}");
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChatScreen(
            currentUserPhone: widget.currentUserPhone,
            otherUser: user,
          ),
        ),
      );
    } else {
      // Single tap - announce contact name
      await _tts.speak("${user.username}, phone: ${user.phone}. Double tap to open chat.");
    }
    _lastTap = now;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Start New Chat",
          style: GoogleFonts.poppins(
            fontSize: _isMagnified ? 22 : 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: _primaryColor,
        actions: [_buildMagnifierButton()],
      ),
      body: Container(
        color: _secondaryColor.withOpacity(0.1),
        child: FutureBuilder<List<User>>(
          future: _userFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(_primaryColor),
                ),
              );
            }

            if (snapshot.hasError) {
              return Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    "Error loading users",
                    style: _getTextStyle(true),
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            final users = snapshot.data!;
            if (users.isEmpty) {
              return GestureDetector(
                onTap: () => _tts.speak("No users available"),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.group_rounded,
                        size: _isMagnified ? 80 : 60,
                        color: _primaryColor.withOpacity(0.3),
                      ),
                      SizedBox(height: 16),
                      Text(
                        "No users available",
                        style: _getTextStyle(true),
                      ),
                      SizedBox(height: 8),
                      Text(
                        "All registered users will appear here",
                        style: _getTextStyle(false),
                      ),
                    ],
                  ),
                ),
              );
            }

            return ListView.builder(
              padding: EdgeInsets.all(_isMagnified ? 16 : 12),
              itemCount: users.length,
              itemBuilder: (context, index) {
                final user = users[index];
                return GestureDetector(
                  onTap: () => _handleTap(user),
                  child: Card(
                    elevation: 2,
                    margin: EdgeInsets.symmetric(
                      vertical: _isMagnified ? 10 : 8,
                      horizontal: _isMagnified ? 8 : 4,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(
                        vertical: _isMagnified ? 16 : 12,
                        horizontal: _isMagnified ? 20 : 16,
                      ),
                      leading: CircleAvatar(
                        radius: _isMagnified ? 28 : 24,
                        backgroundColor: _primaryColor,
                        child: Text(
                          user.username[0].toUpperCase(),
                          style: GoogleFonts.poppins(
                            fontSize: _isMagnified ? 20 : 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      title: Text(
                        user.username,
                        style: _getTextStyle(true),
                      ),
                      subtitle: Text(
                        user.phone,
                        style: _getTextStyle(false).copyWith(
                          color: _textColor.withOpacity(0.7),
                        ),
                      ),
                      trailing: Icon(
                        Icons.chat_rounded,
                        color: _primaryColor,
                        size: _isMagnified ? 32 : 28,
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}